import React from "react";
import Header from "../parts/Header";
import Footer from "../parts/Footer";

const Category = () => {
    return (
        <>
            <div>Category ! Page building in progress</div>
        </>
    );
};

export default Category;