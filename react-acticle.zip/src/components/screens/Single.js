import React from "react";
import Header from "../parts/Header";
import Footer from "../parts/Footer";

const Single = () => {
    return (
        <>
            <div>Single ! In progress</div>
        </>
    );
};

export default Single;