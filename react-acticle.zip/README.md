Live Demo - https://sudhakarsblog.netlify.app/

Screenshots:

![image](https://user-images.githubusercontent.com/72399139/111035868-66a92080-8442-11eb-8361-20898c22a439.png)
